// Ajusta o projeto Android gerado pelo Capacitor para o AdMob.
// Rodar dentro da pasta memoria-frutas, depois de "npx cap add android".
import fs from 'node:fs';

const APP_ID = 'ca-app-pub-3967121863180958~1102054948'; // ID do app no AdMob

const manifest = 'android/app/src/main/AndroidManifest.xml';
let m = fs.readFileSync(manifest, 'utf8');
if (!m.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  m = m.replace(
    '</application>',
    '    <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="@string/admob_app_id"/>\n    </application>'
  );
  fs.writeFileSync(manifest, m);
}

const strings = 'android/app/src/main/res/values/strings.xml';
let s = fs.readFileSync(strings, 'utf8');
if (!s.includes('admob_app_id')) {
  s = s.replace('</resources>', `    <string name="admob_app_id">${APP_ID}</string>\n</resources>`);
  fs.writeFileSync(strings, s);
}
console.log('AdMob configurado no Android.');
