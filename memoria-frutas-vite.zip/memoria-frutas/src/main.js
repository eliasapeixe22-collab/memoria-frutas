import { ADS } from './config.js';
import { isNative, initAds, showRewarded, showInterstitial } from './ads.js';

// ===== Dados do jogo =====
const FRUITS=['🍎','🍌','🍇','🍓','🍊','🍉','🍍','🥝','🍒','🍐','🥭','🍋','🍑','🥥','🍈','🫐','🍅','🥑'];
// [pares, colunas, segundos]
const LEVELS=[[3,3,40],[4,4,45],[6,4,60],[8,4,70],[10,5,80],[12,4,90],[15,5,105],[18,6,120]];

const $=id=>document.getElementById(id);
const store={
  get(k,d){try{const v=localStorage.getItem(k);return v===null?d:JSON.parse(v)}catch(e){return d}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
};

let prev=null,level=Math.min(store.get('mjb_level',0),LEVELS.length-1),score=0,deck=[],open=[],matched=0,moves=0,left=0,total=0,lock=true,timer=null,wins=store.get('mjb_wins',0);

const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const fmt=t=>Math.floor(t/60)+':'+String(t%60).padStart(2,'0');
const el=i=>$('board').children[i];

function hud(){
  $('lvl').textContent=level+1;$('score').textContent=score;$('time').textContent=fmt(left);
  $('time').classList.toggle('low',left<=10);$('bar').style.width=(total?left/total*100:0)+'%';
}
function msg(t){$('msg').textContent=t}

// ===== Jogo =====
function startLevel(){
  stopTimer();clearTimeout(prev);
  const [pairs,cols,secs]=LEVELS[level];
  deck=shuffle([...FRUITS.slice(0,pairs),...FRUITS.slice(0,pairs)]).map(f=>({f,done:false}));
  open=[];matched=0;moves=0;total=left=secs;lock=true;
  const b=$('board');b.style.setProperty('--c',cols);b.innerHTML='';
  deck.forEach((c,i)=>{
    const e=document.createElement('button');
    e.className='card open';e.innerHTML='<span>'+c.f+'</span>';
    e.setAttribute('aria-label','carta '+(i+1));e.onclick=()=>pick(i);b.appendChild(e);
  });
  hud();msg('Memorize as frutas…');
  prev=setTimeout(()=>{
    [...b.children].forEach(e=>e.classList.remove('open'));
    lock=false;msg('Encontre os pares antes que o tempo acabe!');runTimer();
  },900+pairs*180);
}
function runTimer(){stopTimer();timer=setInterval(()=>{left--;hud();if(left<=0){stopTimer();lose()}},1000)}
function stopTimer(){clearInterval(timer);timer=null}

function pick(i){
  if(lock||deck[i].done||open.includes(i))return;
  open.push(i);el(i).classList.add('open');
  if(open.length<2)return;
  moves++;const[a,b]=open;
  if(deck[a].f===deck[b].f){
    deck[a].done=deck[b].done=true;
    [a,b].forEach(k=>{el(k).classList.remove('open');el(k).classList.add('done')});
    open=[];matched++;score+=10;hud();msg('Par encontrado! +10');
    if(matched===deck.length/2)win();
  }else{
    lock=true;msg('Não combinou. Memorize e tente de novo.');
    setTimeout(()=>{[a,b].forEach(k=>el(k).classList.remove('open'));open=[];lock=false},650);
  }
}

function win(){
  stopTimer();lock=true;
  const bonus=left*2;score+=bonus;hud();
  const r=left/total,stars=r>.5?3:r>.2?2:1;
  const last=level===LEVELS.length-1;
  wins++;store.set('mjb_wins',wins);
  if(!last){level++;store.set('mjb_level',level)}
  const best=Math.max(store.get('mjb_best',0),score);store.set('mjb_best',best);
  showBox(`<h2>${last?'Você zerou o jogo!':'Nível completo!'}</h2><div class="stars">${'⭐'.repeat(stars)}${'☆'.repeat(3-stars)}</div>
  <p>Bônus de tempo: +${bonus}<br>Pontos: ${score} · Recorde: ${best}</p>
  <button class="btn main" id="b1">${last?'Jogar de novo':'Próximo nível'}</button>`,
  ()=>{$('b1').onclick=()=>{
    closeBox();
    if(last){level=0;score=0;store.set('mjb_level',0);startLevel()}
    else if(wins%ADS.interstitialEvery===0){showAd('interstitial',startLevel)}
    else startLevel();
  }});
}

function lose(){
  lock=true;
  showBox(`<h2>Tempo esgotado</h2><p>Você achou ${matched} de ${deck.length/2} pares.</p>
  <button class="btn main" id="b1">+${ADS.extraTime}s assistindo anúncio</button>
  <button class="btn alt" id="b2">Tentar o nível de novo</button>`,
  ()=>{
    $('b1').onclick=()=>{closeBox();showAd('rewarded',()=>{
      left=ADS.extraTime;total=Math.max(total,left);lock=false;hud();msg('+'+ADS.extraTime+' segundos!');runTimer();
    })};
    $('b2').onclick=()=>{closeBox();score=Math.max(0,score-matched*10);startLevel()};
  });
}

// ===== Dica (anúncio premiado) =====
$('hint').onclick=()=>{
  if(lock||!timer)return;
  showAd('rewarded',()=>{
    const g={};deck.forEach((c,i)=>{if(!c.done)(g[c.f]??=[]).push(i)});
    const p=Object.values(g).find(x=>x.length>1);if(!p)return;
    open.forEach(k=>el(k).classList.remove('open'));open=[];
    p.forEach(k=>el(k).classList.add('open','hint'));lock=true;msg('Dica: guarde a posição destas frutas!');
    setTimeout(()=>{p.forEach(k=>el(k).classList.remove('open','hint'));lock=false},1400);
  });
};
$('restart').onclick=startLevel;

// ===== Anúncios =====
// No app Android usa o AdMob real (src/ads.js). No navegador usa o simulador abaixo.
async function showAd(kind,onDone){
  if(!isNative)return fakeAd(kind,onDone);
  const wasRunning=timer!==null;stopTimer();lock=true;
  const resume=()=>{if(wasRunning){lock=false;runTimer()}};
  if(kind==='rewarded'){
    const ok=await showRewarded();
    resume();
    if(ok)onDone();
    else{msg('Anúncio indisponível ou fechado antes do fim.');if(!wasRunning)lose()}
  }else{
    await showInterstitial();
    resume();onDone();
  }
}

function fakeAd(kind,onDone){
  const rew=kind==='rewarded',secs=rew?ADS.rewardedSeconds:ADS.interstitialSeconds;
  const wasRunning=timer!==null;stopTimer();lock=true;
  showBox(`<h2>${rew?'Anúncio premiado':'Anúncio'}</h2>
  <div class="adfake">Anúncio simulado (${rew?'vídeo premiado':'intersticial'})<b id="cd">${secs}</b></div>
  <button class="btn main" id="b1" disabled>${rew?'Aguarde para receber':'Aguarde…'}</button>`,
  ()=>{
    let s=secs;
    const t=setInterval(()=>{
      s--;$('cd').textContent=Math.max(s,0);
      if(s<=0){clearInterval(t);$('b1').disabled=false;$('b1').textContent=rew?'Receber recompensa':'Fechar'}
    },1000);
    $('b1').onclick=()=>{closeBox();if(wasRunning){lock=false;runTimer()}onDone()};
  });
}

// ===== Janela =====
function showBox(html,bind){$('box').innerHTML=html;$('ov').classList.add('on');bind&&bind()}
function closeBox(){$('ov').classList.remove('on')}

// ===== Início =====
initAds();
startLevel();
