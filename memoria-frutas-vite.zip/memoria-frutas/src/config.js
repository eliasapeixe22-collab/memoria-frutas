// ===== Configuração de anúncios =====
// TEST = true  -> usa blocos de TESTE do Google (seguro para desenvolver e testar).
// TEST = false -> usa os SEUS blocos reais do AdMob (só na versão final da loja).
// Nunca clique nos seus próprios anúncios reais.
export const TEST = true;

const IDS_TEST = {
  banner: 'ca-app-pub-3940256099942544/6300978111',
  interstitial: 'ca-app-pub-3940256099942544/1033173712',
  rewarded: 'ca-app-pub-3940256099942544/5224354917'
};

const IDS_REAL = {
  banner: 'ca-app-pub-3967121863180958/9755319010',       // banner_inferior
  interstitial: 'ca-app-pub-3967121863180958/3373617189', // intersticial_niveis
  rewarded: 'ca-app-pub-3967121863180958/7987027495'      // premiado_dica
};

export const IDS = TEST ? IDS_TEST : IDS_REAL;

// Regras do jogo ligadas aos anúncios
export const ADS = {
  interstitialEvery: 3, // intersticial a cada N níveis concluídos
  extraTime: 15,        // segundos ganhos ao assistir o anúncio premiado
  // Só para o simulador do navegador:
  rewardedSeconds: 5,
  interstitialSeconds: 3
};
