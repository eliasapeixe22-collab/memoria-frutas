import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdSize,
  BannerAdPosition,
  RewardAdPluginEvents,
  InterstitialAdPluginEvents
} from '@capacitor-community/admob';
import { TEST, IDS } from './config.js';

// true só dentro do app Android; no navegador o jogo usa anúncios simulados
export const isNative = Capacitor.isNativePlatform();

export async function initAds() {
  if (!isNative) return;
  try {
    // 1) Consentimento (exigido em alguns países, como os da Europa)
    const info = await AdMob.requestConsentInfo();
    if (info.isConsentFormAvailable && info.status === AdmobConsentStatus.REQUIRED) {
      await AdMob.showConsentForm();
    }
    // 2) Iniciar o SDK
    await AdMob.initialize({ initializeForTesting: TEST });
    // 3) Banner fixo embaixo (esconde o espaço simulado)
    const fake = document.querySelector('.banner');
    if (fake) fake.style.display = 'none';
    await AdMob.showBanner({
      adId: IDS.banner,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: TEST
    });
  } catch (e) {
    console.warn('AdMob init:', e);
  }
}

// Anúncio premiado. Retorna true se o jogador ganhou a recompensa.
export async function showRewarded() {
  let earned = false, h1, h2;
  try {
    const dismissed = new Promise((resolve) => {
      AdMob.addListener(RewardAdPluginEvents.Rewarded, () => { earned = true; }).then((h) => (h1 = h));
      AdMob.addListener(RewardAdPluginEvents.Dismissed, () => resolve()).then((h) => (h2 = h));
    });
    await AdMob.prepareRewardVideoAd({ adId: IDS.rewarded, isTesting: TEST });
    await AdMob.showRewardVideoAd();
    await dismissed;
  } catch (e) {
    console.warn('Anúncio premiado:', e);
  } finally {
    h1 && h1.remove();
    h2 && h2.remove();
  }
  return earned;
}

// Anúncio intersticial. Resolve quando o jogador fecha (ou se falhar).
export async function showInterstitial() {
  let h;
  try {
    const dismissed = new Promise((resolve) => {
      AdMob.addListener(InterstitialAdPluginEvents.Dismissed, () => resolve()).then((x) => (h = x));
    });
    await AdMob.prepareInterstitial({ adId: IDS.interstitial, isTesting: TEST });
    await AdMob.showInterstitial();
    await dismissed;
  } catch (e) {
    console.warn('Intersticial:', e);
  } finally {
    h && h.remove();
  }
}
