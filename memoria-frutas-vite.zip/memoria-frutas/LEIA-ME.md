# Memória das Frutas — Vite + Capacitor + AdMob

Projeto do jogo, pronto para virar app Android.

## Estrutura
- `index.html` e `src/style.css`: tela do jogo
- `src/main.js`: lógica do jogo (níveis, tempo, memória, dica)
- `src/ads.js`: AdMob real (banner, intersticial, premiado, consentimento)
- `src/config.js`: **chave TEST e IDs dos anúncios** (teste e reais)
- `scripts/patch-android.mjs`: coloca o ID do app AdMob no Android
- `capacitor.config.json`: nome e identificador do app (`com.minijogosbrasil.memoriafrutas`)

## Compilar sem computador (GitHub Actions)
Veja o passo a passo enviado no chat. Resumo: suba este .zip em um repositório privado do GitHub junto com o arquivo `.github/workflows/build.yml`. O GitHub compila e gera o APK de teste.

## Compilar no computador (Node.js LTS e Android Studio)
```bash
npm install @capacitor/core @capacitor/android @capacitor-community/admob
npm install -D vite @capacitor/cli
npm run build
npx cap add android
node scripts/patch-android.mjs
npm run sync
npm run open
```

## Testar no navegador
```bash
npm run dev
```
No navegador os anúncios são simulados.

## Ir para a produção
1. `src/config.js`: mude `TEST` para `false` (usa os IDs reais do AdMob).
2. Gere o .aab assinado e envie ao Play Console (política de privacidade, teste fechado de 12 testadores por 14 dias etc.).
3. Depois de publicado, no AdMob: Apps > Memória das Frutas > Configurações do app > Detalhes da app store > Adicionar.

**Nunca clique nos seus próprios anúncios reais.** Use TEST = true enquanto desenvolve.
